<!DOCTYPE html>
<html>
<head>
             <title>118470356 </title>
                <link rel="stylesheet" href="stylesheet.css" type="text/css" />
<style>
.button {
  background-color: red;
  border: none;
  color: white;
  padding: 15px 32px;
  
  
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
</style>
</head>
<body background="red.jpg">
<h1 class="mainheading">1183470356 - Home!</h1>
                
                
                <br/>
                <a href="is1113118365381.herokuapp.com">is1113118470356.herokuapp.com</a>
                <br/>
                <a href="https.//github.com/DanielMorrissey/is1113118470356/graphs/commit-activity">GitHub</a>
        <br>
       
                 
<h2>Home Page</h2>
<br>
<a href="CV.html" class="button">View CV </a>
</br>
<br>
<a href="tiltedpage_scroll_demo.html" class="button">View Tilted page scroll of interest </a>
</br>
<br>
<a href="ebus1.php" class="button">Consultancy calculator </a>
</br>
</body>
</html>
